from __future__ import annotations

import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ai.reasoning import build_reasoning
from ai.remediation import suggest_fix

from alerts.email_alerts import (
    mail_alerts_enabled,
    send_critical_mail,
)

from core.crypto import (
    build_cipher,
    hash_secret,
    hmac_sha256_hex,
)

from core.exposure import (
    calculate_exposure_score,
    get_first_commit_date,
    hydrate_missing_exposure_fields,
)

from security.github_clone import (
    clone_repository,
    cleanup_repository,
)

from security.secret_scanner import (
    scan_file,
    should_skip_file,
)

from security.git_history_scanner import GitHistoryScanError, scan_git_history
from security.semgrep.service import SemgrepService

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from groq import Groq
from pydantic import BaseModel
from supabase import Client, create_client
from supabase.lib.client_options import SyncClientOptions

import tempfile
import subprocess
import shutil

BACKEND_ROOT = Path(__file__).resolve().parent
REPO_ROOT = BACKEND_ROOT.parent
for env_path in (BACKEND_ROOT / ".env", REPO_ROOT / ".env"):
    if env_path.exists():
        load_dotenv(env_path, override=False)


SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_KEY = os.environ["SUPABASE_KEY"]
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
HMAC_SECRET_KEY = os.environ.get("HMAC_SECRET_KEY", "").strip()
ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY", "").strip()

if not ENCRYPTION_KEY:
    raise RuntimeError("ENCRYPTION_KEY is required in .env")

SMTP_HOST = os.environ.get("SMTP_HOST", "").strip()
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "").strip()
SMTP_PASSWORD = "".join(os.environ.get("SMTP_PASSWORD", "").split())
SMTP_USE_TLS = os.environ.get("SMTP_USE_TLS", "true").strip().lower() in {"1", "true", "yes", "on"}
SMTP_USE_SSL = os.environ.get("SMTP_USE_SSL", "false").strip().lower() in {"1", "true", "yes", "on"}
SMTP_TIMEOUT = float(os.environ.get("SMTP_TIMEOUT", "15"))
ALERT_EMAIL_FROM = os.environ.get("ALERT_EMAIL_FROM", "").strip()
ALERT_EMAIL_TO = [
    recipient.strip()
    for recipient in os.environ.get("ALERT_EMAIL_TO", "").split(",")
    if recipient.strip()
]
ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.environ.get(
        "ALLOWED_ORIGINS",
        "http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if origin.strip()
]

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
groq_client = Groq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None


cipher = build_cipher(ENCRYPTION_KEY)

def debug_log(*args, **kwargs):
    """Print with automatic flush for logging"""
    print(*args, **kwargs, file=sys.stderr, flush=True)
    sys.stdout.flush()


app = FastAPI(title="DarkShield Backend", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS or ["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)


# NOTE: the secret-detection PATTERNS and SKIP_EXT tables live in
# security/secret_scanner.py (imported above via `scan_file` / `should_skip_file`).
# They are intentionally not duplicated here — a previous copy of both dicts
# existed in this file and had drifted out of sync with the real ones; it was
# removed as part of Phase 0 cleanup.


class ScanRequest(BaseModel):
    repo_id: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _safe_repo_lookup(client: Client, repo_id: str) -> dict[str, Any]:
    response = client.table("repos").select("*").eq("id", repo_id).limit(1).execute()
    rows = getattr(response, "data", []) or []
    if not rows:
        raise HTTPException(status_code=404, detail="Repo not found")
    return rows[0]


def _parse_status(status: str | None) -> str:
    value = str(status or "").upper().strip()
    if value in {"PENDING", "SCANNING", "DONE", "ERROR"}:
        return value.lower()
    return "pending"


def _supabase_for_request(request: Request | None) -> Client:
    if request is not None:
        authorization = request.headers.get("authorization", "")
        if authorization.lower().startswith("bearer "):
            token = authorization.split(" ", maxsplit=1)[1].strip()
            if token:
                return create_client(
                    SUPABASE_URL,
                    SUPABASE_KEY,
                    options=SyncClientOptions(
                        headers={"Authorization": f"Bearer {token}"},
                        auto_refresh_token=False,
                        persist_session=False,
                    ),
                )

    return supabase

def _severity_rank(severity: str) -> int:
    mapping = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
    return mapping.get(severity.upper(), 1)

def _distinct_repo_count_for_hash(client: Client, secret_hash: str) -> int:
    response = client.table("findings").select("repo_id").eq("secret_hash", secret_hash).execute()
    rows = getattr(response, "data", []) or []
    return len({str(row.get("repo_id") or "") for row in rows if row.get("repo_id")})


def _aggregate_clusters(client: Client) -> list[dict[str, Any]]:
    response = client.table("findings").select("secret_hash,secret_type,severity,created_at,repo_id").execute()
    rows = getattr(response, "data", []) or []
    grouped: dict[str, dict[str, Any]] = {}

    for row in rows:
        secret_hash = str(row.get("secret_hash") or "").strip()
        if not secret_hash:
            continue

        group = grouped.setdefault(
            secret_hash,
            {
                "id": secret_hash,
                "secret_hash": secret_hash,
                "secret_type": row.get("secret_type") or "Unknown",
                "severity": row.get("severity") or "LOW",
                "repo_ids": set(),
                "created_at": row.get("created_at"),
            },
        )
        if row.get("repo_id"):
            group["repo_ids"].add(str(row["repo_id"]))
        if _severity_rank(str(row.get("severity") or "LOW")) > _severity_rank(str(group["severity"])):
            group["severity"] = row.get("severity") or group["severity"]
        if row.get("created_at") and (not group["created_at"] or str(row["created_at"]) < str(group["created_at"])):
            group["created_at"] = row.get("created_at")

    result: list[dict[str, Any]] = []
    for group in grouped.values():
        repo_ids = group.pop("repo_ids")
        repo_count = len(repo_ids)
        if repo_count < 2:
            continue
        group["repo_count"] = repo_count
        result.append(group)

    result.sort(key=lambda item: (item.get("repo_count", 0), item.get("created_at") or ""), reverse=True)
    return result

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/scan")
async def scan_repo(req: ScanRequest, request: Request) -> dict[str, Any]:
    print(f"\nSCAN: Starting scan for repo ID: {req.repo_id}")
    client = _supabase_for_request(request)
    repo = _safe_repo_lookup(client, req.repo_id)
    owner = str(repo.get("owner") or "").strip()
    name = str(repo.get("name") or "").strip()
    github_url = str(repo.get("github_url") or "").strip()

    print(f"SCAN: {owner}/{name}")
    client.table("repos").update({"status": "scanning"}).eq("id", req.repo_id).execute()

    headers: dict[str, str] = {"Accept": "application/vnd.github+json"}
    if GITHUB_TOKEN:
        headers["Authorization"] = f"Bearer {GITHUB_TOKEN}"

    semgrep_service = SemgrepService()

    cloned_repo_path = None
    semgrep_result = None

    try:
        cloned_repo_path = clone_repository(
            github_url,
            full_history=True,
        )

        print(
            f"SEMGREP: Repository cloned to {cloned_repo_path}"
        )

        semgrep_result = (
            semgrep_service.analyze_and_convert(
                repo_id=req.repo_id,
                repo_path=cloned_repo_path,
            )
        )

        print(
            f"SEMGREP: Found {len(semgrep_result['records'])} findings"
        )

        findings_raw: list[dict[str, Any]] = []   

    except Exception as exc:

        print(
            f"WARNING: Semgrep scan failed: {exc}"
        )

        semgrep_result = {
            "records": [],
            "categories": [],
            "owasp_context": "",
            "total_findings": 0,
        }    

    try:
        async with httpx.AsyncClient(timeout=30, headers=headers) as http_client:
            tree_resp = await http_client.get(
                f"https://api.github.com/repos/{owner}/{name}/git/trees/HEAD?recursive=1"
            )
            if tree_resp.status_code != 200:
                print(f"ERROR: Failed to fetch repo tree: {tree_resp.status_code}")
                client.table("repos").update({"status": "error"}).eq("id", req.repo_id).execute()
                raise HTTPException(status_code=400, detail="Could not fetch repo. Is it public?")

            tree = tree_resp.json().get("tree", [])
            files = [
                item
                for item in tree
                if item.get("type") == "blob" and not should_skip_file(str(item.get("path") or ""), item.get("size"))
            ]

            print(f"SCAN: Scanning {len(files)} files...")
            for file_item in files[:200]:
                await scan_file(
                    client=http_client,
                    owner=owner,
                    name=name,
                    file_path=str(file_item.get("path") or ""),
                    repo_id=req.repo_id,
                    findings=findings_raw,
                    get_first_commit_date=get_first_commit_date,
                    hash_secret=hash_secret,
                    encrypt_snippet=cipher.encrypt,
                    calculate_exposure_score=calculate_exposure_score,
                    hmac_secret_key=HMAC_SECRET_KEY
                )
    except HTTPException:
        raise
    except Exception as exc:
        print(f"ERROR: Scan failed: {exc}")
        client.table("repos").update({"status": "error"}).eq("id", req.repo_id).execute()
        raise HTTPException(status_code=500, detail=f"Repository scan failed: {type(exc).__name__}: {exc}") from exc

    seen: set[tuple[str, str, int]] = set()
    unique_findings: list[dict[str, Any]] = []
    for finding in findings_raw:
        key = (finding["secret_hash"], finding["file_path"], int(finding["line_number"]))
        if key in seen:
            continue
        seen.add(key)
        finding.setdefault("found_in", "current")
        unique_findings.append(finding)

    print(f"OK: Found {len(unique_findings)} unique secrets")

    # Git history scan (Phase 3): catches secrets that were committed and
    # later removed from the current tree, which the current-HEAD scan
    # above can't see. Non-fatal - a failure here (timeout, huge history,
    # corrupted repo) should not fail the whole /scan request, since the
    # current-HEAD findings and Semgrep results are still valid on their own.
    history_findings: list[dict[str, Any]] = []
    if cloned_repo_path:
        try:
            current_secret_keys = {
                (f["file_path"], f["secret_hash"]) for f in unique_findings
            }

            raw_history_findings = scan_git_history(
                repo_path=cloned_repo_path,
                repo_id=req.repo_id,
                hash_secret=hash_secret,
                encrypt_snippet=cipher.encrypt,
                hmac_secret_key=HMAC_SECRET_KEY,
            )

            # Skip anything already reported as a live, current-HEAD finding -
            # the history copy is redundant once the secret is already flagged
            # as still-present-today.
            history_findings = [
                hf
                for hf in raw_history_findings
                if (hf["file_path"], hf["secret_hash"]) not in current_secret_keys
            ]

            print(
                f"HISTORY: Found {len(history_findings)} secret(s) only in git "
                f"history (not present in current HEAD)"
            )

        except GitHistoryScanError as exc:
            print(f"WARNING: Git history scan failed: {exc}")

    unique_findings.extend(history_findings)

    semgrep_findings = (
        semgrep_result["records"]
    )

    print(
        f"SEMGREP: {len(semgrep_findings)} findings"
    )

    all_findings = (
        unique_findings
        + semgrep_findings
    )

    # AI-powered remediation suggestions (Phase 6): bounded to the top 10
    # CRITICAL/HIGH Semgrep findings only. Deliberately excludes raw
    # secret-scanner findings - see the docstring in ai/remediation.py for
    # why (their snippet can contain a live secret value; the fix for a
    # leaked secret is always "rotate it," not something an AI call adds
    # value to). Capped at 10 to bound Groq API cost/latency per scan -
    # these are sequential blocking calls, same style as build_reasoning
    # below; parallelizing with asyncio.gather is a reasonable future
    # optimization but not required for a lab-scale demo.
    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    remediation_candidates = sorted(
        (
            finding
            for finding in semgrep_findings
            if str(finding.get("severity") or "").upper() in ("CRITICAL", "HIGH")
        ),
        key=lambda finding: severity_rank.get(str(finding.get("severity") or "").upper(), 4),
    )[:10]

    if remediation_candidates:
        print(f"AI: Generating remediation suggestions for {len(remediation_candidates)} finding(s)...")
        for finding in remediation_candidates:
            finding["ai_suggested_fix"] = suggest_fix(finding, groq_client)

    for finding in unique_findings:
        finding["cluster_id"] = None

    if unique_findings:
        print("DB: Saving findings to database...")
        client.table("findings").upsert(
            all_findings,
            on_conflict="repo_id,file_path,line_number,secret_hash",
        ).execute()
        print("OK: Findings saved")

    findings_for_reasoning: list[dict[str, Any]] = []
    for finding in unique_findings:
        finding["cluster_repo_count"] = _distinct_repo_count_for_hash(client, finding["secret_hash"])
        findings_for_reasoning.append(finding)

    print("AI: Generating AI reasoning...")
    ai_reasoning = build_reasoning(owner, name, findings_for_reasoning, groq_client)
    critical_findings = [finding for finding in unique_findings if str(finding.get("severity") or "").upper() == "CRITICAL"]
    print(f"ALERT: Critical findings: {len(critical_findings)}")
    
    mail_sent, mail_error = send_critical_mail(
                                client=client,
                                repo_id=req.repo_id,
                                owner=owner,
                                name=name,
                                repo_url=github_url,
                                critical_findings=critical_findings,
                                ai_reasoning=ai_reasoning,
                                total_count=len(all_findings),
                                smtp_host=SMTP_HOST,
                                smtp_port=SMTP_PORT,
                                smtp_user=SMTP_USER,
                                smtp_password=SMTP_PASSWORD,
                                smtp_use_ssl=SMTP_USE_SSL,
                                smtp_use_tls=SMTP_USE_TLS,
                                smtp_timeout=SMTP_TIMEOUT,
                                alert_email_from=ALERT_EMAIL_FROM,
                                alert_email_to=ALERT_EMAIL_TO,
                                hmac_sha256_hex=hmac_sha256_hex,
                                debug_log=debug_log,
                            )

    try:
        client.table("repos").update(
            {
                "status": "done",
                "last_scanned_at": _now_iso(),
                "finding_count": len(all_findings),
                "ai_reasoning": ai_reasoning,
            }
        ).eq("id", req.repo_id).execute()
    except Exception as exc:
        print(f"WARNING: Failed to finalize repo scan status: {exc}")

    print(f"OK: Scan complete for {owner}/{name}")

    if cloned_repo_path:

        try:
            shutil.rmtree(
                cloned_repo_path,
                ignore_errors=True,
            )

        except Exception:
            pass

    return {
        "repo_id": req.repo_id,
        "github_url": github_url,
        "total": len(all_findings),
        "ai_reasoning": ai_reasoning,
        "critical_alerts_enabled": mail_alerts_enabled(
            SMTP_HOST,
            SMTP_USER,
            SMTP_PASSWORD,
            ALERT_EMAIL_TO,
        ),
        "critical_alert_email_sent": mail_sent,
        "critical_alert_error": mail_error,
        "critical_findings": len(critical_findings),
    }


@app.delete("/repos/{repo_id}")
async def delete_repo(repo_id: str, request: Request) -> dict[str, Any]:
    client = _supabase_for_request(request)
    repo = _safe_repo_lookup(client, repo_id)
    client.table("repos").delete().eq("id", repo_id).execute()
    return {
        "deleted": True,
        "repo_id": repo_id,
        "github_url": repo.get("github_url"),
        "owner": repo.get("owner"),
        "name": repo.get("name"),
    }


@app.get("/findings/{repo_id}")
async def get_findings(repo_id: str, request: Request) -> list[dict[str, Any]]:
    client = _supabase_for_request(request)
    repo = _safe_repo_lookup(client, repo_id)
    response = (
        client.table("findings")
        .select("*")
        .eq("repo_id", repo_id)
        .order("created_at", desc=True)
        .execute()
    )
    findings = getattr(response, "data", []) or []
    
    # Decrypt snippets on retrieval
    for finding in findings:
        if finding.get("snippet_enc"):
            finding["snippet"] = cipher.decrypt(finding["snippet_enc"])
        # Include exposure duration and score in response for older rows too.
        if finding.get("exposure_days") is None and finding.get("first_commit_date"):
            first_commit = datetime.fromisoformat(finding["first_commit_date"].replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            exposure_days = max(0, (now - first_commit).days)
            finding["exposure_days"] = exposure_days
            finding["exposure_score"] = calculate_exposure_score(
                finding.get("severity", "LOW"),
                exposure_days,
            )
    findings = await hydrate_missing_exposure_fields(client, str(repo.get("owner") or ""), str(repo.get("name") or ""), findings)

    return findings


@app.get("/clusters")
async def get_clusters(request: Request) -> list[dict[str, Any]]:
    client = _supabase_for_request(request)
    return _aggregate_clusters(client)